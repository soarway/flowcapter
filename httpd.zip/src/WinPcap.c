//--------------------------------------������˵����-------------------------------------------
//		����������Winpcap��ץ���뻹ԭ
//		�����������ò���ϵͳ�� Windows 8.1 64bit
//		������������IDE�汾��Visual Studio 2015
//		2015��11��28�� Created by @CodeLadyJJY
//------------------------------------------------------------------------------------------------

#ifdef _DEBUG
#include<vld.h>
#endif

#include "pcap.h"
#include "uhttpd.h"

#include <string.h>

#ifdef _WIN32

#include <Windows.h>
#include <winsock.h>
#include <process.h>

#pragma comment(lib, "wpcap.lib")
#pragma comment(lib, "Ws2_32.lib")
#endif


#define   FILE_NAME     "./filedata.obs"


#define LINE_LEN     16
#define MAX_ADDR_LEN 32

char macaddr[128] = { 0 };

#define  RECV_DIR  1
#define  SEND_DIR  2

time_t  flowSecondRecv[2] = { 0 };
time_t  flowSecondSend[2] = { 0 };

volatile int  g_exit = 0;
int  flowMinuteRecv[61] = { 0 };
int  flowMinuteSend[61] = { 0 };
time_t  flowHourRecv[25] = { 0 };
time_t  flowHourSend[25] = { 0 };
time_t  flowDayRecv[32] = { 0 };
time_t  flowDaySend[32] = { 0 };

//�����60���ӵ�����
int  _flowMinuteRecv[61] = { 0 };
int  _flowMinuteSend[61] = { 0 };
//�����24Сʱ������
time_t  _flowHourRecv[25] = { 0 };
time_t  _flowHourSend[25] = { 0 };
//�����30�������
time_t  _flowDayRecv[32] = { 0 };
time_t  _flowDaySend[32] = { 0 };

time_t  total_send = 0;
time_t  total_recv = 0;



static void parse_arg_list(int, char* []);

static const char* help_content =
"uHttpd Version 1.00 Powered by Lewis Cheng (2011.09)\n\n"
"Usage: %s [-a | --address IP] [-p | --port Port]\n\n"
"Spec:\n"
"IP:\t\t\tDefault value is ANY.\n"
"Port:\t\t\tDefault value is 80.\n"
"Hotkey:\n"
"Ctrl-C:\t\t\tStop the server and all workers.\n"
"Ctrl-Z:\t\t\tShow memory allocation statistics.\n";



void write_data()
{

	FILE* fp = fopen(FILE_NAME, "w+");
	if (fp == NULL)		return;
	if (total_send == 0) return;

	fwrite(&total_send, sizeof(time_t), 1, fp);
	fwrite(&total_recv, sizeof(time_t), 1, fp);
	fwrite(flowHourSend, sizeof(time_t), sizeof(flowHourSend) / sizeof(time_t), fp);
	fwrite(flowHourRecv, sizeof(time_t), sizeof(flowHourRecv) / sizeof(time_t), fp);

	fclose(fp);
}


void read_data()
{
	FILE* fp = fopen(FILE_NAME, "rb");
	if (fp == NULL)
		return;

	fread(&total_send, sizeof(time_t), 1, fp);
	fread(&total_recv, sizeof(time_t), 1, fp);
	fread(flowHourSend, sizeof(time_t), sizeof(flowHourSend) / sizeof(time_t), fp);
	fread(flowHourRecv, sizeof(time_t), sizeof(flowHourRecv) / sizeof(time_t), fp);

	fclose(fp);
}



static void print_help_exit(char* name) {
	printf(help_content, strrchr(name, '/') + 1);
	exit(0);
}

static void parse_arg_list(int argc, char* argv[]) {
	int i;
	for (i = 1; i < argc; ++i) {
		if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
			print_help_exit(argv[0]);
		}
		else if (!strcmp(argv[i], "-a") || !strcmp(argv[i], "--address")) {
			if (++i == argc) {
				fprintf(stderr, "IP is missing.\n");
				print_help_exit(argv[0]);
			}
			if (strcmp(argv[i], "ANY")) {
#ifdef _WIN32
				server_address = inet_pton(AF_INET, argv[i], &server_address);
#else
				server_address = inet_addr(argv[i]);
#endif
				if (server_address == INADDR_NONE) {
					fprintf(stderr, "IP is wrong.\n");
					print_help_exit(argv[0]);
				}
			}
		}
		else if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--port")) {
			if (++i == argc) {
				fprintf(stderr, "Port is missing.\n");
				print_help_exit(argv[0]);
			}
			server_port = atoi(argv[i]);//�����˿�
			//if (server_port < 1024 && server_port != 80) {
			//	fprintf(stderr, "Port is out of valid range(=80 or >1023).\n");
			//	print_help_exit(argv[0]);
			//}
		}
		else if (!strcmp(argv[i], "-m") || !strcmp(argv[i], "--mac")) {
			if (++i == argc) {
				fprintf(stderr, "mac is missing.\n");
				print_help_exit(argv[0]);
			}
			//������mac��ַ
#ifdef _WIN32
			strcpy_s(macaddr, sizeof(macaddr), argv[i]);
#else
			assert(sizeof(macaddr) > strlen(macaddr));
			strcpy(macaddr, argv[i]);
			fprintf(stdout, "macaddr=%s\n", macaddr);
#endif
		
			//server_port = atoi(argv[i]);
			//if (server_port < 1024 && server_port != 80) {
			//	fprintf(stderr, "Port is out of valid range(=80 or >1023).\n");
			//	print_help_exit(argv[0]);
			//}
		}
		else if (!strcmp(argv[i], "-i") || !strcmp(argv[i], "--interface")) {
			if (++i == argc) {
				fprintf(stderr, "interface is missing.\n");
				print_help_exit(argv[0]);
			}
			select_interface = atoi(argv[i]);
		}
		else {
			fprintf(stderr, "Unknown argument: %s.\n", argv[i]);
			print_help_exit(argv[0]);
		}
	}
}


void updateData(int dir, int len)
{
	time_t local_tv_sec = time(0);
	struct tm* ltime = localtime(&local_tv_sec);
	assert(dir > 0);
	//int i;

	if (dir == RECV_DIR) {
		if (flowSecondRecv[0] == local_tv_sec) {
			flowSecondRecv[1] += len;
		}
		else {
			flowSecondRecv[0] = local_tv_sec;
			flowSecondRecv[1] = len;
		}

		if (flowMinuteRecv[0] == ltime->tm_hour) {
			flowMinuteRecv[ltime->tm_min + 1] += len;
		}
		else {
			memcpy(_flowMinuteRecv, flowMinuteRecv, sizeof(flowMinuteRecv));
			memset(flowMinuteRecv, 0, sizeof(flowMinuteRecv));
			flowMinuteRecv[0] = ltime->tm_hour;
			flowMinuteRecv[ltime->tm_min + 1] = len;
		}

		if (flowHourRecv[0] == ltime->tm_mday)
		{
			flowHourRecv[ltime->tm_hour+1] += len;
		}
		else {
			memcpy(_flowHourRecv, flowHourRecv, sizeof(flowHourRecv));
			memset(flowHourRecv, 0, sizeof(flowHourRecv));

			flowHourRecv[0] = ltime->tm_mday;
			flowHourRecv[ltime->tm_hour + 1] = len;
		}

		if (flowDayRecv[0] == ltime->tm_mon) {
			flowDayRecv[ltime->tm_mday] += len;
		}
		else {
			memcpy(_flowDayRecv, flowDayRecv, sizeof(flowDayRecv));
			memset(flowDayRecv, 0, sizeof(flowDayRecv));
			flowDayRecv[0] = ltime->tm_mon;
			flowDayRecv[ltime->tm_mday] = len;
		}

		total_recv += len;

	}


	if (dir == SEND_DIR) {
		if (flowSecondSend[0] == local_tv_sec) {
			flowSecondSend[1] += len;
		}
		else {
			flowSecondSend[0] = local_tv_sec;
			flowSecondSend[1] = len;
		}

		if (flowMinuteSend[0] == ltime->tm_hour) {
			flowMinuteSend[ltime->tm_min + 1] += len;
		}
		else {
			memcpy(_flowMinuteSend, flowMinuteSend, sizeof(flowMinuteSend));
			memset(flowMinuteSend, 0, sizeof(flowMinuteSend));
			flowMinuteSend[0] = ltime->tm_hour;
			flowMinuteSend[ltime->tm_min + 1] = len;

			
		}

		if (flowHourSend[0] == ltime->tm_mday)
		{
			flowHourSend[ltime->tm_hour + 1] += len;
		}
		else {
			memcpy(_flowHourSend, flowHourSend, sizeof(flowHourSend));
			memset(flowHourSend, 0, sizeof(flowHourSend));

			flowHourSend[0] = ltime->tm_mday;
			flowHourSend[ltime->tm_hour + 1] = len;
		}

		if (flowDaySend[0] == ltime->tm_mon) {
			flowDaySend[ltime->tm_mday] += len;
		}
		else {
			memcpy(_flowDaySend, flowDaySend, sizeof(flowDaySend));
			memset(flowDaySend, 0, sizeof(flowDaySend));
			flowDaySend[0] = ltime->tm_mon;
			flowDaySend[ltime->tm_mday] = len;
		}

		total_send += len;
	}

	if(local_tv_sec%60==0)

		write_data();

}


FILE* file = 0;

// ��̫��Э���ʽ�Ķ���
typedef struct ether_header {
	u_char ether_dhost[6];		// Ŀ��MAC��ַ
	u_char ether_shost[6];		// ԴMAC��ַ
	u_short ether_type;			// ��̫������
}ether_header;

// �û�����4�ֽڵ�IP��ַ
typedef struct ip_address {
	u_char byte1;
	u_char byte2;
	u_char byte3;
	u_char byte4;
}ip_address;

// ���ڱ���IPV4���ײ�
typedef struct ip_header {
	u_char version_hlen;		// �ײ����� �汾
	u_char tos;					// ��������
	u_short tlen;				// �ܳ���
	u_short identification;		// ����ʶ��
	u_short flags_offset;		// ��ʶ ����ƫ��
	u_char ttl;					// ��������
	u_char proto;				// Э������
	u_short checksum;			// ��ͷ������
	u_int saddr;				// ԴIP��ַ
	u_int daddr;				// Ŀ��IP��ַ
}ip_header;

// ���ڱ���TCP�ײ�
typedef struct tcp_header {
	u_short sport;
	u_short dport;
	u_int sequence;				// ������
	u_int ack;					// �ظ���
	u_char hdrLen;				// �ײ����ȱ�����
	u_char flags;				// ��־
	u_short windows;			// ���ڴ�С
	u_short checksum;			// У���
	u_short urgent_pointer;		// ����ָ��
}tcp_header;

// ���ڱ���UDP���ײ�
typedef struct udp_header {
	u_short sport;				// Դ�˿�
	u_short dport;				// Ŀ��˿�
	u_short datalen;			// UDP���ݳ���
	u_short checksum;			// У���
}udp_header;

// ���ڱ���ICMP���ײ�
typedef struct icmp_header {
	u_char type;				// ICMP����
	u_char code;				// ����
	u_short checksum;			// У���
	u_short identification;		// ��ʶ
	u_short sequence;			// ���к�
	u_long timestamp;			// ʱ���
}icmp_header;

// ���ڱ���ARP���ײ�
typedef struct arp_header {
	u_short hardware_type;					// ��ʽ����Ӳ����ַ
	u_short protocol_type;					// Э���ַ��ʽ
	u_char hardware_length;					// Ӳ����ַ����
	u_char protocol_length;					// Э���ַ����
	u_short operation_code;					// ������
	u_char source_ethernet_address[6];		// ������Ӳ����ַ
	u_char source_ip_address[4];			// ������Э���ַ
	u_char destination_ethernet_address[6];	// Ŀ�ķ�Ӳ����ַ
	u_char destination_ip_address[4];		// Ŀ�ķ�Э���ַ
}arp_header;

// TCPЭ�鴦��
//u_short sport;
//u_short dport;
//u_int sequence;			// ������
//u_int ack;				// �ظ���
//u_char hdrLen;			// �ײ����ȱ�����
//u_char flags;				// ��־
//u_short windows;			// ���ڴ�С
//u_short checksum;			// У���
//u_short urgent_pointer;	// ����ָ��
void tcp_protocol_packet_handle(u_char* arg, const struct pcap_pkthdr* pkt_header, const u_char* pkt_content)
{
	tcp_header* tcp_protocol;

	tcp_protocol = (tcp_header*)(pkt_content + 14 + 20);

	printf("===================TCP Protocol=================\n");

	printf("Source Port: %i\n", ntohs(tcp_protocol->sport));
	printf("Destination Port: %i\n", ntohs(tcp_protocol->dport));
	printf("Sequence number: %d\n", ntohl(tcp_protocol->sequence));
	printf("Acknowledgment number: %d\n", ntohl(tcp_protocol->ack));
	printf("Header Length: %d\n", (tcp_protocol->hdrLen >> 4) * 4);
	printf("Flags: 0x%.3x ", tcp_protocol->flags);
	if (tcp_protocol->flags & 0x08) printf("(PSH)");
	if (tcp_protocol->flags & 0x10) printf("(ACK)");
	if (tcp_protocol->flags & 0x02) printf("(SYN)");
	if (tcp_protocol->flags & 0x20) printf("(URG)");
	if (tcp_protocol->flags & 0x01) printf("(FIN)");
	if (tcp_protocol->flags & 0x04) printf("(RST)");
	printf("\n");
	printf("Windows Size: %i\n", ntohs(tcp_protocol->windows));
	printf("Checksum: 0x%.4x\n", ntohs(tcp_protocol->checksum));
	printf("Urgent Pointer: %i\n", ntohs(tcp_protocol->urgent_pointer));
}

// UDPЭ�鴦��
//u_short sport;			// Դ�˿�
//u_short dport;			// Ŀ��˿�
//u_short datalen;			// UDP���ݳ���
//u_short checksum;			// У���
void udp_protocol_packet_handle(u_char* arg, const struct pcap_pkthdr* pkt_header, const u_char* pkt_content)
{
	udp_header* udp_protocol;

	udp_protocol = (udp_header*)(pkt_content + 14 + 20);

	printf("===================UDP Protocol=================\n");
	printf("Source Port: %i\n", ntohs(udp_protocol->sport));
	printf("Destination Port: %i\n", ntohs(udp_protocol->dport));
	printf("Datalen: %i\n", ntohs(udp_protocol->datalen));
	printf("Checksum: 0x%.4x\n", ntohs(udp_protocol->checksum));
}

// ICMPЭ�鴦��
//u_char type;				// ICMP����
//u_char code;				// ����
//u_short checksum;			// У���
//u_short identification;	// ��ʶ
//u_short sequence;			// ���к�
//u_long timestamp;			// ʱ���
void icmp_protocol_packet_handle(u_char* arg, const struct pcap_pkthdr* pkt_header, const u_char* pkt_content)
{
	icmp_header* icmp_protocol;

	icmp_protocol = (icmp_header*)(pkt_content + 14 + 20);

	printf("==================ICMP Protocol=================\n");
	printf("Type: %d ", icmp_protocol->type);
	switch (icmp_protocol->type)
	{
	case 8:
		printf("(request)\n");
		break;
	case 0:
		printf("(reply)\n");
		break;
	default:
		printf("\n");
		break;
	}
	printf("Code: %d\n", icmp_protocol->code);
	printf("CheckSum: 0x%.4x\n", ntohs(icmp_protocol->checksum));
	printf("Identification: 0x%.4x\n", ntohs(icmp_protocol->identification));
	printf("Sequence: 0x%.4x\n", ntohs(icmp_protocol->sequence));
}

// ARPЭ�鴦��
//u_short hardware_type;					// ��ʽ����Ӳ����ַ
//u_short protocol_type;					// Э���ַ��ʽ
//u_char hardware_length;					// Ӳ����ַ����
//u_char protocol_length;					// Э���ַ����
//u_short operation_code;					// ������
//u_char source_ethernet_address[6];		// ������Ӳ����ַ
//u_char source_ip_address[4];				// ������Э���ַ
//u_char destination_ethernet_address[6];	// Ŀ�ķ�Ӳ����ַ
//u_char destination_ip_address[4];			// Ŀ�ķ�Э���ַ
void arp_protocol_packet_handle(u_char* arg, const struct pcap_pkthdr* pkt_header, const u_char* pkt_content)
{
	arp_header* arp_protocol;

	arp_protocol = (arp_header*)(pkt_content + 14);

	printf("==================ARP Protocol==================\n");
	printf("Hardware Type: ");
	switch (ntohs(arp_protocol->hardware_type))
	{
	case 1:
		printf("Ethernet");
		break;
	default:
		break;
	}
	printf(" (%d)\n", ntohs(arp_protocol->hardware_type));
	printf("Protocol Type: \n");
	switch (ntohs(arp_protocol->protocol_type))
	{
	case 0x0800:
		printf("%s", "IP");
		break;
	case 0x0806:
		printf("%s", "ARP");
		break;
	case 0x0835:
		printf("%s", "RARP");
		break;
	default:
		printf("%s", "Unknown Protocol");
		break;
	}
	printf(" (0x%04x)\n", ntohs(arp_protocol->protocol_type));
	printf("Hardware Length: %d\n", arp_protocol->hardware_length);
	printf("Protocol Length: %d\n", arp_protocol->protocol_length);
	printf("Operation Code: ");
	switch (ntohs(arp_protocol->operation_code))
	{
	case 1:
		printf("request");
		break;
	case 2:
		printf("reply");
		break;
	default:
		break;
	}
	printf(" (%i)\n", ntohs(arp_protocol->operation_code));
}

// IPЭ�鴦��
//u_char version_hlen;		// �ײ����� �汾
//u_char tos;				// ��������
//u_short tlen;				// �ܳ���
//u_short identification;	// ����ʶ��
//u_short flags_offset;		// ��ʶ ����ƫ��
//u_char ttl;				// ��������
//u_char proto;				// Э������
//u_short checksum;			// ��ͷ������
//u_int saddr;				// ԴIP��ַ
//u_int daddr;				// Ŀ��IP��ַ
void ip_protocol_packet_handle(u_char* arg, const struct pcap_pkthdr* pkt_header, const u_char* pkt_content, int direction, bpf_u_int32 len)
{
	ip_header* ip_protocol;
	struct sockaddr_in source, dest;
	char sourceIP[MAX_ADDR_LEN], destIP[MAX_ADDR_LEN];

	ip_protocol = (ip_header*)(pkt_content + 14);
	source.sin_addr.s_addr = ip_protocol->saddr;
	dest.sin_addr.s_addr = ip_protocol->daddr;

#ifdef _WIN32
	PCSTR ptr1 = inet_ntop(AF_INET, &(source.sin_addr), sourceIP, sizeof(sourceIP));
	PCSTR ptr2 = inet_ntop(AF_INET, &(source.sin_addr), destIP, sizeof(destIP));
#else
	strncpy(sourceIP, inet_ntoa(source.sin_addr), MAX_ADDR_LEN);
	strncpy(destIP, inet_ntoa(dest.sin_addr), MAX_ADDR_LEN);
#endif

	/*
	printf("===================IP Protocol==================\n");
	printf("Version: %d\n", ip_protocol->version_hlen >> 4);
	printf("Header Length: %d bytes\n", (ip_protocol->version_hlen & 0x0f) * 4);
	printf("Tos: %d\n", ip_protocol->tos);
	printf("Total Length: %d\n", ntohs(ip_protocol->tlen));
	printf("Identification: 0x%.4x (%i)\n", ntohs(ip_protocol->identification), ntohs(ip_protocol->identification));
	printf("Flags: %d\n", ntohs(ip_protocol->flags_offset) >> 13);
	printf("---Reserved bit: %d\n", (ntohs(ip_protocol->flags_offset) & 0x8000) >> 15);
	printf("---Don't fragment: %d\n", (ntohs(ip_protocol->flags_offset) & 0x4000) >> 14);
	printf("---More fragment: %d\n", (ntohs(ip_protocol->flags_offset) & 0x2000) >> 13);
	printf("Fragment offset: %d\n", ntohs(ip_protocol->flags_offset) & 0x1fff);
	printf("Time to live: %d\n", ip_protocol->ttl);
	printf("Protocol Type: ");*/
	switch (ip_protocol->proto)
	{
	case 1:
		printf("ICMP ");
		break;
	case 6:
		printf("TCP: ");
		updateData(direction, len);

		break;
	case 17:
		printf("UDP ");
		break;
	default:
		break;
	}
	//printf(" (%d)\n", ip_protocol->proto);
	//printf("Header checkSum: 0x%.4x\n", ntohs(ip_protocol->checksum));
	printf("Source: %s    Destin: %s\n", sourceIP, destIP);
	//printf("Destin: %s\n", destIP);
	/*
	if (ip_protocol->proto == htons(0x0600))
		tcp_protocol_packet_handle(arg, pkt_header, pkt_content);
	else if (ip_protocol->proto == htons(0x1100))
		udp_protocol_packet_handle(arg, pkt_header, pkt_content);
	else if (ip_protocol->proto == htons(0x0100))
		icmp_protocol_packet_handle(arg, pkt_header, pkt_content);
	*/
}

// EthernetЭ�鴦��
void ethernet_protocol_packet_handle(u_char* arg, const struct pcap_pkthdr* pkt_header, const u_char* pkt_content, bpf_u_int32 len)
{
	ether_header* ethernet_protocol;//��̫��Э��
	u_short ethernet_type;			//��̫������
	u_char* mac_string;				//��̫����ַ
	char src[128] = { 0 };
	char dst[128] = { 0 };

	int direction = 0;
	//��ȡ��̫����������
	ethernet_protocol = (ether_header*)pkt_content;
	ethernet_type = ntohs(ethernet_protocol->ether_type);

	printf("==============Ethernet Protocol=================\n");

	//��̫��Ŀ���ַ
	mac_string = ethernet_protocol->ether_dhost;

	//printf("Dest Mac Address: %02X-%02X-%02X-%02X-%02X-%02X\n",
	//	*mac_string,
	//	*(mac_string + 1),
	//	*(mac_string + 2),
	//	*(mac_string + 3),
	//	*(mac_string + 4),
	//	*(mac_string + 5));

	sprintf(dst, "%02X-%02X-%02X-%02X-%02X-%02X", *mac_string,
		*(mac_string + 1),
		*(mac_string + 2),
		*(mac_string + 3),
		*(mac_string + 4),
		*(mac_string + 5));

	//��̫��Դ��ַ
	mac_string = ethernet_protocol->ether_shost;

	//printf("Source Mac Address: %02X-%02X-%02X-%02X-%02X-%02X\n",
	//	*mac_string,
	//	*(mac_string + 1),
	//	*(mac_string + 2),
	//	*(mac_string + 3),
	//	*(mac_string + 4),
	//	*(mac_string + 5));

	sprintf(src, "%02X-%02X-%02X-%02X-%02X-%02X", *mac_string,
		*(mac_string + 1),
		*(mac_string + 2),
		*(mac_string + 3),
		*(mac_string + 4),
		*(mac_string + 5));

	//�ж����ݷ���
	if (strcmp(dst, macaddr) == 0) {
		direction = RECV_DIR;
	}
	else if (strcmp(src, macaddr) == 0) {
		direction = SEND_DIR;
	}
	else {
		printf("src=%s, dst=%s, mac=%s\n", src, dst, macaddr);
		printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
		return;
	}

	//printf("Ethernet type: ");
	switch (ethernet_type)
	{
	case 0x0800:
		printf("%s", "IP");
		break;
	case 0x0806:
		printf("%s", "ARP");
		break;
	case 0x0835:
		printf("%s", "RARP");
		break;
	default:
		printf("%s", "Unknown Protocol");
		break;
	}
	printf(" (0x%04x)\n", ethernet_type);

	switch (ethernet_type)
	{
	case 0x0800:
		ip_protocol_packet_handle(arg, pkt_header, pkt_content, direction, len);
		break;
	case 0x0806:
		//arp_protocol_packet_handle(arg, pkt_header, pkt_content);
		break;
	case 0x0835:
		//printf("==============RARP Protocol=================\n");
		//printf("RARP\n");
		break;
	default:
		//printf("==============Unknown Protocol==============\n");
		//printf("Unknown Protocol\n");
		break;
	}
}

#ifdef _WIN32
unsigned __stdcall HttpThread(void* args)
#else
void* HttpThread(void* args)
#endif
{
	//const char* wk = (char*)args;

#ifndef _WIN32
	// Setup signals.
	if (signal(SIGPIPE, SIG_IGN) == SIG_ERR ||
		signal(SIGINT, stop_process) == SIG_ERR ||
		signal(SIGTERM, stop_process) == SIG_ERR ||
		signal(SIGTSTP, SIG_IGN) == SIG_ERR)
		report_fatal("start_server()", "Fail to setup signals");
#endif

	// Create server socket.
	//socket(AF_INET, SOCK_STREAM, 0)

	int server_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
	if (server_sock == -1)
		report_fatal("start_server()", "Fail to create server socket");

	int one = 1;
	if (setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) < 0) {
#ifdef _WIN32
		closesocket(server_sock);
		return 0;
#else
		close(server_sock);
		return NULL;
#endif

	}

	struct sockaddr_in server_addr;
	memset(&server_addr, 0, sizeof(struct sockaddr_in));

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(server_port);

#ifdef _WIN32
	
	 inet_pton ( AF_INET, "127.0.0.1", (void*)&server_addr.sin_addr ) ; // htonl(INADDR_ANY);
#else
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // htonl(INADDR_ANY);
#endif

	// Bind server socket to server_address.
	if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(struct sockaddr)) == -1)
		report_fatal("start_server()", "Fail to bind server socket");

	// Listen on server_port.
	if (listen(server_sock, MAX_PENDING_CONNECTIONS) == -1)
		report_fatal("start_server()", "Fail to listen server socket");





	// Main loop of server.
	while (1) {
		if (g_exit == 1)
			break;

		struct sockaddr_in client_addr;
		int client_addr_len = sizeof(client_addr);

		// Accept a client connection.
#ifdef _WIN32
		struct timeval timeout1 = { 6,0 };
		struct timeval timeout2 = { 6,0 };
		setsockopt(server_sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout1, sizeof(struct timeval));
		setsockopt(server_sock, SOL_SOCKET, SO_SNDTIMEO, (char*)&timeout2, sizeof(struct timeval));
		
		int client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_addr_len);
#else
		int client_sock = accept(server_sock, (struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len);
#endif
		if (client_sock == -1) {
			report_error("start_server()", "Client socket is invalid");
			continue;
		}

#ifdef _WIN32
		HANDLE hThread;
		unsigned int threadid;
		ARGS* pargs = xmalloc(sizeof(ARGS));
		pargs->client_sock = client_sock;
		pargs->server_sock = server_sock;
		hThread = (HANDLE)_beginthreadex(NULL, 0, HttpWorkerThread, pargs, 0, &threadid);
		CloseHandle(hThread);
#else
		/*
		if (fork() == 0) {
			// Call worker to do succeeding work.
			worker(client_sock,  wkdir);
		} else {
			// Server doesn't need talk to client.
			close(client_sock);
		}
		*/
		ARGS* pargs = xmalloc(sizeof(ARGS));
		pargs->client_sock = client_sock;
		pargs->server_sock = server_sock;

		pthread_t thread;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, 1);
		pthread_create(&thread, &attr, HttpWorkerThread, pargs);

#endif

	}

#ifdef _WIN32
	closesocket(server_sock);
	g_exit = 50;
	return 0;
#else
	close(server_sock);
	g_exit = 50;
	return NULL;
#endif

}

char workdir[256] = { 0 };

int main(int argc, char** argv)
{
	pcap_if_t* alldevs;	//�������б�������һ�����������ݽṹ
	pcap_if_t* d;		//����ĳ��������
	pcap_t* fp;
	int res;
	struct pcap_pkthdr* header;
	const u_char* pkt_data;
	time_t local_tv_sec;
	struct tm* ltime;
	char timestr[16];

	int count = 1;
	int i = 0, inum;
	char errbuf[PCAP_ERRBUF_SIZE];

	if (argc < 2) return -1;

//-------------------------------------------------------------------------------------------------------
#ifdef _WIN32
	WSADATA wsd;
	if (WSAStartup(MAKEWORD(2, 2), &wsd) != 0) {
		printf("Winsock Init fail!\n");
		return 1;
	}
#endif


	read_data();//��ȡ��ʷ����

#ifdef _WIN32
	char* p = strrchr(argv[0], '\\');
#else
	char* p = strrchr(argv[0], '/');
#endif
	size_t n = (p - argv[0]);
	strncpy(workdir, argv[0], n);//����Ŀ¼


	parse_arg_list(argc, argv);//��������
	open_logfile(NULL);


	//start_server(workdir);
//--------------------------------------------------------------------------------------------------------------------




	printf("===============Adapter List===============\n");

	//��ȡ�����豸�б�
	if (pcap_findalldevs(&alldevs, errbuf) == -1)
	{
		fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
		exit(1);
	}

	//����б�
	for (d = alldevs; d != NULL; d = d->next)
	{
		char ipbuf[64] = { 0 };
		

		//if (d->addresses->addr->sa_family == AF_INET6) {

		//	const char* ps = inet_ntop(d->addresses->addr->sa_family, (struct sockaddr_in*)d->addresses->addr, ipbuf, sizeof(ipbuf));
		//	printf(" %s  ", ps);
	 //   }

		printf("%d. %s", ++i, d->name);

	
		if (d->description)
			printf(" (%s)\n", d->description);
		else
			printf(" (No description available)\n");
	}

	if (i == 0)
	{
		printf("\nNo interfaces found! Make sure WinPcap is installed.\n");
		return -1;
	}

	if (select_interface > 0)
	{
		inum = select_interface;
	}
	else {
		//��ȡѡ����
		while (1)
		{
			printf("\nEnter the interface ID (1-%d): ", i);
			scanf("%d", &inum);

			if (inum > 0 && inum <= i)
				break;
		}	
	}


	//�����û�ѡ���������
	for (d = alldevs, i = 0; i < inum - 1; ++i, d = d->next);


	//��������
	if ((fp = pcap_open_live(d->name, 65536, 1, 1000, errbuf)) == NULL)
	{
		fprintf(stderr, "\nError openning adapter: %s\n", errbuf);
		pcap_freealldevs(alldevs);
		return -1;
	}

	//�����·�������
	if (pcap_datalink(fp) != DLT_EN10MB)
	{
		fprintf(stderr, "This program only run on Ethernet networks\n");
		pcap_close(fp);
		pcap_freealldevs(alldevs);
		return -1;
	}

	printf("The program is start working......\n");
	//printf("The capture file is saving as 'data.txt'\n");
	printf("You can input 'ctrl + C' to stop the program\n");

	//if ((file = freopen("data.txt", "w", stdout)) == 0)
	//	printf("Cannot open the file.\n");


#ifdef _WIN32
	HANDLE hThread;
	unsigned int threadid;

	hThread = (HANDLE)_beginthreadex(NULL, 0, &HttpThread, workdir, 0, &threadid);
	CloseHandle(hThread);

#else
	pthread_t thread;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, 1);
	pthread_create(&thread, &attr, HttpThread, NULL);
#endif


	int jsq = 0;

REDO:
	while ((res = pcap_next_ex(fp, &header, &pkt_data)) >= 0)
	{
	
		//��ʱ
		if (res == 0)
			continue;

		jsq++;
		//if (jsq > 300)
		//{
		//	res = -1;
		//	break;
		//}
		//��ʱ���ת��Ϊ��ʶ���ʽ
		local_tv_sec = header->ts.tv_sec;
		ltime = localtime(&local_tv_sec);
		strftime(timestr, sizeof(timestr), "%H:%M:%S", ltime);

		//�����š�ʱ����Ͱ�����
		//printf("==============================================================================\n");
		//printf("No.%d\ttime: %s\tlen: %d\n", count++, timestr, header->len);
		//printf("==============================================================================\n");

		printf("\n");

		//�������ݰ�
		ethernet_protocol_packet_handle(NULL, header, pkt_data, header->len);

		//printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
		//printf("flowHourRecv = \n");
		//for (i = 0; i < 25; i++) {
		//	printf("%lld ", flowHourRecv[i]);
		//}
		//printf("\n");
		//printf("flowHourSend = \n");
		//for (i = 0; i < 25; i++) {
		//	printf("%lld ", flowHourSend[i]);
		//}
		//printf("\n");
		//printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	}


	g_exit = 1;
	while (g_exit != 100) {
		Sleep(1000);
	}



	//�ͷ�
	pcap_close(fp);
	pcap_freealldevs(alldevs);
	fclose(stdin);
	//if (file)
	//	fclose(file);

	return 0;
}