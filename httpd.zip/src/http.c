 
#include "uhttpd.h"


extern time_t  flowSecondRecv[2] ;
extern time_t  flowSecondSend[2] ;

extern int  flowMinuteRecv[61] ;
extern int  flowMinuteSend[61] ;
extern time_t  flowHourRecv[25] ;
extern time_t  flowHourSend[25] ;
extern time_t  flowDayRecv[32] ;
extern time_t  flowDaySend[32] ;

extern int  _flowMinuteRecv[61];
extern int  _flowMinuteSend[61];
extern time_t  _flowHourRecv[25];
extern time_t  _flowHourSend[25];
extern time_t  _flowDayRecv[32];
extern time_t  _flowDaySend[32];

extern time_t total_send;
extern time_t total_recv;


void free_packet(packet_type *packet) {
	assert(packet != NULL);

	xfree(packet->buf, __FILE__, __LINE__);
	xfree(packet, __FILE__, __LINE__);
}

packet_type *read_packet(int client_sock) 
{
	packet_type *packet = xmalloc(sizeof(packet_type));
	packet->buf = xmalloc(MAX_PACKET_SIZE);
	memset(packet->buf, 1, MAX_PACKET_SIZE);

	packet->size = xread(client_sock, packet->buf, MAX_PACKET_SIZE);
	if (packet->size <= 0)
	{
		free_packet(packet);
		return NULL;
	}
	return packet;
}

int write_packet(int client_sock, packet_type *packet) 
{
	assert(packet != NULL);
	
	int bytes_write = xwrite(client_sock, packet->buf, packet->size);
	if (bytes_write == packet->size)
		return 0;
	else
		return -1;
}

http_request_type *create_request_from_packet(const packet_type *packet)
{
	assert(packet != NULL);
	
	http_request_type *request = xmalloc(sizeof(http_request_type));
	request->method = NULL;
	request->url = NULL;
	request->version = NULL;
	request->connection = NULL;
	request->content_type = NULL;
	request->content_length = 0;
	request->content = NULL;
	
	const char *ptr = packet->buf;
	//printf("create_request_from_packet=\n%s\n", ptr);
	// Parse method.
	request->method = xstralloc(MAX_METHOD_LENGTH);
	ptr = copy_to_stop_char(request->method, 0, ptr, ' ', MAX_METHOD_LENGTH);
	if (ptr == NULL)
		return request;

	++ptr; // Skip the space.

	// Parse URL.
	request->url = xstralloc(MAX_URL_LENGTH);
	ptr = copy_to_stop_char(request->url, 0, ptr, ' ', MAX_URL_LENGTH);
	if (ptr == NULL)
		return request;
	++ptr; // Skip the space.

	if (strstr(request->url, "/flow/") == NULL)
	{
		free_request(request);
		return NULL;
	}

	// Parse version.
	request->version = xstralloc(MAX_VERSION_LENGTH);
	ptr = copy_to_stop_char(request->version, 0, ptr, '\r', MAX_VERSION_LENGTH);
	ASSERT(ptr, *(ptr + 1) == '\n');
	ptr += 2; // Skip '\r\n'.
	
	// Parse header fields.
	char *field = xstralloc(MAX_HEADER_FIELD_LENGTH);
	while (*ptr != '\r' && *ptr != '\0') {
		ptr = copy_to_stop_char(field, 0, ptr, ':', MAX_HEADER_FIELD_LENGTH);
		if (ptr == NULL) break;
		ASSERT(ptr, *(ptr + 1) == ' ');
		ptr += 2; // Skip ": "

		char *value = xstralloc(MAX_HEADER_VALUE_LENGTH);
		ptr = copy_to_stop_char(value, 0, ptr, '\r', MAX_HEADER_VALUE_LENGTH);
		if (ptr == NULL) {
			xfree(value, __FILE__, __LINE__);
			break;
		}
		ASSERT(ptr, *(ptr + 1) == '\n');
		ptr += 2; // Skip "\r\n"

		if (!xstrcmp(field, "Content-Type", MAX_HEADER_FIELD_LENGTH)) {
			request->content_type = value;
		} else if (!xstrcmp(field, "Content-Length", MAX_HEADER_FIELD_LENGTH)) {
			request->content_length = atoi(value);
			xfree(value, __FILE__, __LINE__);
			if (request->content_length > 0)
				request->content = xmalloc(request->content_length);
		} else if (!xstrcmp(field, "Connection", MAX_HEADER_FIELD_LENGTH)) {
			request->connection = value;
		} else {
			xfree(value, __FILE__, __LINE__);
		}
	}
	xfree(field, __FILE__, __LINE__);
	
	if (ptr == NULL) {
		return request;
	}
	ASSERT(ptr, *(ptr + 1) == '\n');
	ptr += 2; // Skip the last "\r\n" of the header.
	
	if (request->content_length > 0)
		memcpy(request->content, ptr, request->content_length);
	
	/*
	report_info("create_request_from_packet()",
		"\nMethod = %s\nURL = %s\nVersion = %s\nConnection = %s\nContent-Type = %s\nContent-Length = %u",
		request->method,
		request->url,
		request->version,
		request->connection,
		request->content_type,
		request->content_length);
		*/
	return request;
}

static void set_http_abnormal_status_response(http_request_type *request, http_response_type *response, int status_code) 
{
	response->version = "HTTP/1.1";
	response->connection = "close";
	response->content_type = "text/html";
	response->content = NULL;
	
	switch (status_code) {
	case 400:
		response->code_plus_desc = "400 Bad Request";
		response->content = xmalloc(MAX_INTERNAL_HTML_SIZE);
		snprintf(response->content, MAX_INTERNAL_HTML_SIZE,
			"<html>\r\n"
			"\t<body>\r\n"
			"\t\t<h1>%s</h1>\r\n"
			"\t\t<p>The URL '%s' you requested is not understandable by this server.</p>\r\n"
			"\t\t<hr>\r\n"
			"\t\t<p>If you have any questions, please contact the website administrator.</p>\r\n"
			"\t</body>\r\n"
			"</html>\r\n",
			response->code_plus_desc,
			request->url);
		break;
	case 404:
		response->code_plus_desc = "404 Not Found";
		response->content = xmalloc(MAX_INTERNAL_HTML_SIZE);
		snprintf(response->content, MAX_INTERNAL_HTML_SIZE,
			"<html>\r\n"
			"\t<body>\r\n"
			"\t\t<h1>%s</h1>\r\n"
			"\t\t<p>The URL '%s' you requested doesn't exist on  this server.</p>\r\n"
			"\t\t<hr>\r\n"
			"\t\t<p>If you have any questions, please contact the website administrator.</p>\r\n"
			"\t</body>\r\n"
			"</html>\r\n",
			response->code_plus_desc,
			request->url);
		break;
	case 500:
		response->code_plus_desc = "500 Internal Server Error";
		response->content = xmalloc(MAX_INTERNAL_HTML_SIZE);
		snprintf(response->content, MAX_INTERNAL_HTML_SIZE,
			"<html>\r\n"
			"\t<body>\r\n"
			"\t\t<h1>%s</h1>\r\n"
			"\t\t<p>This server has encountered an error internally, please try it later.</p>\r\n"
			"\t\t<hr>\r\n"
			"\t\t<p>If you have any questions, please contact the website administrator.</p>\r\n"
			"\t</body>\r\n"
			"</html>\r\n",
			response->code_plus_desc);
		break;
	case 501:
		response->code_plus_desc = "501 Not Implemented";
		response->content = xmalloc(MAX_INTERNAL_HTML_SIZE);
		snprintf(response->content, MAX_INTERNAL_HTML_SIZE,
			"<html>\r\n"
			"\t<body>\r\n"
			"\t\t<h1>%s</h1>\r\n"
			"\t\t<p>The method '%s' isn't supported by this server.</p>\r\n"
			"\t\t<hr>\r\n"
			"\t\t<p>If you have any questions, please contact the website administrator.</p>\r\n"
			"\t</body>\r\n"
			"</html>\r\n",
			response->code_plus_desc,
			request->method);
		break;
	case 505:
		response->code_plus_desc = "505 HTTP Version Not Supported";
		response->content = xmalloc(MAX_INTERNAL_HTML_SIZE);
		snprintf(response->content, MAX_INTERNAL_HTML_SIZE,
			"<html>\r\n"
			"\t<body>\r\n"
			"\t\t<h1>%s</h1>\r\n"
			"\t\t<p>This server only supports HTTP 1.0/1.1, but %s requested.</p>\r\n"
			"\t\t<hr>\r\n"
			"\t\t<p>If you have any questions, please contact the website administrator.</p>\r\n"
			"\t</body>\r\n"
			"</html>\r\n",
			response->code_plus_desc,
			request->version);
		break;
	}
	
	response->content_length = xstrlen(response->content, MAX_INTERNAL_HTML_SIZE);
}

const char* json_second =
"{\n"
"\"total_recv\":%lld,\n"
"\"total_send\":%lld,\n"
"\"recv\":%lld,\n"
"\"send\":%lld\n"
"\n}";

const char* json_minute =
"{\n"
"\"total_recv\":%lld,\n"
"\"total_send\":%lld,\n"
"\"recv\":[%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d],\n"
"\"send\":[%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d]\n"
"\n}";

const char* json_hour =
"{\n"
"\"total_recv\":%lld,\n"
"\"total_send\":%lld,\n"
"\"recv\":[%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld],\n"
"\"send\":[%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld]\n"
"\n}";

const char* json_day =
"{\n"
"\"total_recv\":%lld,\n"
"\"total_send\":%lld,\n"
"\"recv\":[%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld],\n"
"\"send\":[%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld]\n"
"\n}";


static void handle_get_post(http_response_type *response, http_request_type *request, const char* wkdir) 
{
	char *path_buf    = xstralloc(MAX_PATH_LENGTH);
	char *arg_str_buf = xstralloc(MAX_ARGUMENT_STRING_LENGTH);
	char *suffix_buf  = xstralloc(MAX_SUFFIX_LENGTH);
	
	int status_code = 200;
	
	if (parse_url(request->url, path_buf, arg_str_buf, suffix_buf) == -1) {
		status_code = 400;
		goto finalize;
	}
	char buffer[8192] = { 0 };

	time_t local_tv_sec = time(0);
	struct tm* ltime = localtime(&local_tv_sec);//�����ͷ�

	// Check method to decide the source of the arguments.
	if (!xstrcmp(request->method, "GET", MAX_METHOD_LENGTH)) {
		// Arguments come from the URL.
		if (strcmp(URL_FLOW_SECOND, path_buf) == 0) {
			snprintf(buffer, sizeof(buffer), json_second, total_recv, total_send, flowSecondRecv[1], flowSecondSend[1]);
		}

		if (strcmp(URL_FLOW_MINUTE, path_buf) == 0) {
			int i = 0;

			int num1 = ltime->tm_min+1;
			//int num2 = 60 - num1;
			int r[60] = { 0 };
			int s[60] = { 0 };
			int j = 0;
			for (i = num1+1; i <= 60; i++)
			{
				r[j] = _flowMinuteRecv[i];
				s[j] = _flowMinuteSend[i];
				j++;
				assert(j < 60);
			}
			for (i = 1; i <= num1; i++)
			{
				r[j] = flowMinuteRecv[i];
				s[j] = flowMinuteSend[i];
				j++;
				assert(j <= 60);
			}
			snprintf(buffer, sizeof(buffer)-1, json_minute, total_recv, total_send,
				r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19], 
				r[20], r[21], r[22], r[23], r[24], r[25], r[26], r[27], r[28], r[29], r[30], r[31], r[32], r[33], r[34], r[35], r[36], r[37], r[38], r[39], 
				r[40], r[41], r[42], r[43], r[44], r[45], r[46], r[47], r[48], r[49], r[50], r[51], r[52], r[53], r[54], r[55], r[56], r[57], r[58], r[59],
				s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8], s[9], s[10], s[11], s[12], s[13], s[14], s[15], s[16], s[17], s[18], s[19],
				s[20], s[21], s[22], s[23], s[24], s[25], s[26], s[27], s[28], s[29], s[30], s[31], s[32], s[33], s[34], s[35], s[36], s[37], s[38], s[39],
				s[40], s[41], s[42], s[43], s[44], s[45], s[46], s[47], s[48], s[49], s[50], s[51], s[52], s[53], s[54], s[55], s[56], s[57], s[58], s[59]);
		}

		if (strcmp(URL_FLOW_HOUR, path_buf) == 0) {
		
			int i = 0;

			int num1 = ltime->tm_hour + 1;
			//int num2 = 24 - num1;
			time_t r[24] = { 0 };
			time_t s[24] = { 0 };
			int j = 0;
			for (i = num1+1; i <= 24; i++)
			{
				r[j] = _flowHourRecv[i];
				s[j] = _flowHourSend[i];
				j++;
				assert(j < 24);
			}
			for (i = 1; i <= num1; i++)
			{
				r[j] = flowHourRecv[i];
				s[j] = flowHourSend[i];
				j++;
				assert(j <= 24);
			}
			snprintf(buffer, sizeof(buffer) - 1, json_hour, total_recv, total_send,
				r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19], r[20], r[21], r[22], r[23], 
				s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8], s[9], s[10], s[11], s[12], s[13], s[14], s[15], s[16], s[17], s[18], s[19], s[20], s[21], s[22], s[23]);

			printf("%s\n", buffer);
		}

		if (strcmp(URL_FLOW_DAY, path_buf) == 0) {
			//snprintf(buffer, sizeof(buffer), json_day, , );
			int i = 0;

			int num1 = ltime->tm_mday ;
			//int num2 = 30 - num1;
			time_t r[31] = { 0 };
			time_t s[31] = { 0 };
			int j = 0;
			for (i = num1 + 1; i <= 30; i++)
			{
				r[j] = _flowDayRecv[i];
				s[j] = _flowDaySend[i];
				j++;
				assert(j < 30);
			}
			for (i = 1; i <= num1; i++)
			{
				r[j] = flowDayRecv[i];
				s[j] = flowDaySend[i];
				j++;
				assert(j <= 30);
			}
			snprintf(buffer, sizeof(buffer) - 1, json_day, total_recv, total_send,
				r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19], r[20], r[21], r[22], r[23], r[24], r[25], r[26], r[27], r[28], r[29],
				s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8], s[9], s[10], s[11], s[12], s[13], s[14], s[15], s[16], s[17], s[18], s[19], s[20], s[21], s[22], s[23], s[24], s[25], s[26], s[27], s[28], s[29]);


		}
	}
	else if (!xstrcmp(request->method, "POST", MAX_METHOD_LENGTH)) {
		if (request->content_length > 0 && request->content != NULL)
			xstrcpy(arg_str_buf, request->content, request->content_length);
	}
	else {
		status_code = 501;
		goto finalize;
	}

	// Create argument list.
	arg_list_type list = create_arg_list(arg_str_buf);
	if (list == NULL) {
		status_code = 400;
		goto finalize;
	}

	size_t len = strlen(buffer);
	// Call .so
	response->content = xmalloc(len+1);
	strcpy(response->content, buffer);
	//size_t count = (*handler)(response->content, list);
	free_arg_list(list);

	// Check return and set content-length.

	response->content_length = len;

	// Fill other fields.
	response->code_plus_desc = "200 OK";
	response->version = "HTTP/1.1";

	if (request->connection == NULL)
		response->connection = "close";
	else
		response->connection = xstrcmp(request->connection, "close", MAX_VERSION_LENGTH) ? "Keep-Alive" : "close";
	response->content_type = get_mime_type("html");

finalize:
	if (status_code != 200)
		set_http_abnormal_status_response(request, response, status_code);
	xfree(path_buf, __FILE__, __LINE__);
	xfree(arg_str_buf, __FILE__, __LINE__);
	xfree(suffix_buf, __FILE__, __LINE__);
}

http_response_type *handle_request(http_request_type *request, const char* wkdir) 
{
	http_response_type *response = xmalloc(sizeof(http_response_type));
	response->version = NULL;
	response->code_plus_desc = NULL;
	response->content_type = NULL;
	response->content_length=0;
	response->connection = NULL;
	response->content = NULL;

	// Check HTTP version.
	if (xstrcmp(request->version, "HTTP/1.1", MAX_VERSION_LENGTH) && xstrcmp(request->version, "HTTP/1.0", MAX_VERSION_LENGTH)) {
		// The opposite side will not use the right version of HTTP so exit.
		set_http_abnormal_status_response(request, response, 505);
		return response;
	}
		
	// Handle method.
	handle_get_post(response, request, wkdir);
	
	return response;
}

packet_type *create_packet_from_response(http_response_type *response)
{
	packet_type *packet = xmalloc(sizeof(packet_type));
	packet->buf = xmalloc(MAX_PACKET_SIZE);
	memset(packet->buf, 2, MAX_PACKET_SIZE);
	packet->size = snprintf(packet->buf, MAX_PACKET_SIZE,
		"%s %s\r\n"
		"Server: %s\r\n"
		"Content-Type: %s\r\n"
		"Content-Length: %zu\r\n"
		"Connection: %s\r\n\r\n",
		response->version,
		response->code_plus_desc,
		server_name,
		response->content_type,
		response->content_length,
		response->connection);
		
	if (packet->size + response->content_length > MAX_PACKET_SIZE) {
		report_error("create_packet_from_response()", "Packet size will be truncated to MAX_PACKET_SIZE");
		response->content_length = MAX_PACKET_SIZE - packet->size;
	}
	
	memcpy(packet->buf + packet->size, response->content, response->content_length);
	packet->size += response->content_length;
	
	/*
	report_info("create_packet_from_response()",
		"\nServer = %s\nResponse = %s\nVersion = %s\nConnection = %s\nContent-Type = %s\nContent-Length = %u",
		server_name,
		response->code_plus_desc,
		response->version,
		response->connection,
		response->content_type,
		response->content_length);
	*/
	return packet;
}

void free_request(http_request_type *request) {
	xfree(request->method, __FILE__, __LINE__);
	xfree(request->url, __FILE__, __LINE__);
	xfree(request->version, __FILE__, __LINE__);
	xfree(request->connection, __FILE__, __LINE__);
	xfree(request->content_type, __FILE__, __LINE__);
	xfree(request->content, __FILE__, __LINE__);
	xfree(request, __FILE__, __LINE__);
}

void free_response(http_response_type *response) 
{

	xfree(response->content, __FILE__, __LINE__);
	xfree(response, __FILE__, __LINE__);
}

