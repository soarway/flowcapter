
#include "uhttpd.h"

in_addr_t server_address = INADDR_ANY;
uint16_t server_port = 80;
uint16_t select_interface = 0;

char *server_name = "uHttpd";
char *default_html_name = "default.html";
char *document_root = "/";

extern char workdir[256];
extern volatile int g_exit;


static void stop_process(int sig) 
{
#ifdef _WIN32
	report_fatal("stop_process()", "Signal caught, process(pid = %u) stopping",  _getpid());
#else
	report_fatal("stop_process()", "Signal '%s' caught, process(pid = %u) stopping", strsignal(sig), getpid());
#endif
}

static void show_xmval(int sig) 
{
	report_info("show_xmval()", "\nIf the worker is suspended, the following value should be 2\n#x_malloc() - #xfree() = %d", get_xmval());
}





#ifdef _WIN32
unsigned __stdcall HttpWorkerThread(void* arg)
#else
void* HttpWorkerThread(void* arg)
#endif
{
	ARGS* pparg = (ARGS*)arg;
	int client_socket = pparg->client_sock;
	int server_socket = pparg->server_sock;
	xfree(pparg, __FILE__, __LINE__);


	while (1)
	{
		if (g_exit == 50)
			break;

		// read packet
		packet_type* packet = read_packet(client_socket);
		if (packet == NULL)
			break;

		// parse request
		http_request_type* request = create_request_from_packet(packet);
		

		// handle request
		http_response_type* response = handle_request(request, workdir);

		// create packet
		packet_type* packet_res = create_packet_from_response(response);

		// write packet
		write_packet(client_socket, packet_res);


		// keep-alive
		if (request->connection != NULL && !xstrcmp(request->connection, "close", MAX_CONNECTION_LENGTH))
		{
			
		}

		free_packet(packet);
		free_packet(packet_res);
		free_request(request);
		free_response(response);
	}
	g_exit = 100;




#ifdef _WIN32
	closesocket(client_socket);
#else
	close(client_socket);
#endif
	


	return 0;

}



