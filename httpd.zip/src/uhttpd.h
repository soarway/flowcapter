
#ifndef UHTTPD_H_INCLUDED
#define UHTTPD_H_INCLUDED

#define  URL_FLOW_SECOND  "/flow/second"
#define  URL_FLOW_MINUTE  "/flow/minute"
#define  URL_FLOW_HOUR    "/flow/hour"
#define  URL_FLOW_DAY     "/flow/day"


#ifdef _WIN32
typedef unsigned long  in_addr_t;
#include <Windows.h>
#include <winsock.h>
#include <process.h>

#else
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <dlfcn.h>
#include <unistd.h>
#include <pthread.h>
#endif

// #define NDEBUG
#include <assert.h>

#include <errno.h>

#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>


#define MAX_PENDING_CONNECTIONS    1
#define MAX_PACKET_SIZE            65531
#define MAX_INTERNAL_HTML_SIZE     1024
#define MAX_PATH_LENGTH            256
#define MAX_ARGUMENT_STRING_LENGTH 256
#define MAX_CONNECTION_LENGTH      15
#define MAX_URL_LENGTH             255
#define MAX_SUFFIX_LENGTH          8
#define MAX_METHOD_LENGTH          8
#define MAX_VERSION_LENGTH         12
#define MAX_HEADER_FIELD_LENGTH    128
#define MAX_HEADER_VALUE_LENGTH    256


typedef struct _args
{
#ifdef _WIN32
	SOCKET client_sock;
	SOCKET server_sock;
#else
	int client_sock;
	int server_sock;
#endif

}ARGS;

extern in_addr_t server_address;
extern uint16_t server_port;
extern uint16_t select_interface;

extern char *server_name;
extern char *default_html_name;
extern char *document_root;


#ifdef _WIN32
unsigned __stdcall HttpWorkerThread(void* arg);
#else
void* HttpWorkerThread(void* arg);
#endif


/*
 * Logging
 */
void open_logfile(const char *);
void report_fatal(const char *, const char *, ...);
void report_error(const char *, const char *, ...);
void report_info(const char *, const char *, ...);

/*
 * Extended memory allocation functions
 */
void *xmalloc(size_t);
void xfree(void *, const char*, int);
// Return a value that increments if xmalloc called and decrements if xfree called
int get_xmval();

/*
 * Extended write and read functions
 */
int xwrite(int, void *, int);
int xread(int, void *, int);

/*
 * Server related
 */
void start_server(const char* dir);

/*
 * MIME type querying
 */
char *get_mime_type(char *);

/*
 * URL and arguments processor
 */
int parse_url(const char *, char *, char *, char *);

#define MAX_KEY_VALUE_LENGTH 32

typedef struct arg_node_tag {
	struct arg_node_tag *link;
	char *key;
	char *value;
} arg_node_type, *arg_list_type;

arg_list_type create_arg_list(const char *);
void free_arg_list(arg_list_type);

/*
 * module
 */
typedef size_t (*handler_type)(char *, arg_list_type);

/*
 * Safe-version string operations
 */
char *xstrcpy(char *, const char *, int);
const char *copy_to_stop_char(char *, int, const char *, char, int);
char *empty_string(char *);
int xstrlen(const char *, int);
int xstrcmp(const char *, const char *, int);
char *xstralloc(int);

/*
 * HTTP structures and operations
 */
typedef struct http_request_tag {
	char *method;
	char *url;
	char *version;
	char *connection;
	char *content_type;
	size_t content_length;
	char *content;
} http_request_type;

typedef struct http_response_tag {
	const char *version;
	const char *code_plus_desc;
	const char *content_type;
	size_t content_length;
	const char *connection;
	char *content;
} http_response_type;

typedef struct {
	char *buf;
	int size;
} packet_type;

packet_type *read_packet(int client_sock);
http_request_type *create_request_from_packet(const packet_type *packet);
void free_packet(packet_type *packet);
http_response_type *handle_request(http_request_type *request, const char* wkdir);
packet_type *create_packet_from_response(http_response_type *response);
int write_packet(int client_sock, packet_type *packet);
void free_request(http_request_type *request);
void free_response(http_response_type *response);


#define ASSERT(ptr,exp) {if(!(exp)){printf("ptr=%s\n",ptr);assert((exp));}}


#endif // UHTTPD_H_INCLUDED
