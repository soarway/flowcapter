
#include "uhttpd.h"

static FILE *strm;

static char *get_time_string() {
	time_t t = time(NULL);
	return ctime(&t);
}

void open_logfile(const char *name) {
	if (name != NULL)
		strm = fopen(name, "a+");
	if (strm == NULL)
		strm = stdout;
}

static void close_logfile() {
	if (strm == NULL || strm == stdout)
		return;
	fclose(strm);
}

void report_fatal(const char *where, const char *format, ...) {
	va_list args;
	va_start(args, format);
	
	fprintf(stdout, "%sFatal: %s: ", get_time_string(), where);
	vfprintf(stdout, format, args);
	fprintf(stdout, "\n\n");
	
	va_end(args);
	close_logfile();

	exit(1);
}

void report_error(const char *where, const char *format, ...) {
	va_list args;
	va_start(args, format);
	
	fprintf(strm, "%sError: %s: ", get_time_string(), where);
	vfprintf(strm, format, args);
	fprintf(strm, "\n\n");
	
	va_end(args);
}

void report_info(const char *where, const char *format, ...) {
	va_list args;
	va_start(args, format);
	
	fprintf(stdout, "%sInfo: %s: ", get_time_string(), where);
	vfprintf(stdout, format, args);
	fprintf(stdout, "\n\n");
	
	va_end(args);
}
