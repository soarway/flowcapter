

#include "uhttpd.h"

static struct module {
	struct module *link;
	char *path;
	void *handle;
	handler_type handler;
} head;

extern char workdir[256] ;
